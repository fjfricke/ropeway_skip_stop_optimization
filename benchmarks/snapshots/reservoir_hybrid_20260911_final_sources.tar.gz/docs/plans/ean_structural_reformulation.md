# EAN Structural Reformulation Plan

Status: **future work**

## Goal

Track larger exact structural reformulations that remain plausible but are not
the automatic next step. Prefer projections and removal of redundant variables
and constraints over alternative Big-M constants, but implement a phase only
when the bottleneck diagnosis in `ean_decomposition.md` supports it.

## Correctness Baseline

All phases must preserve the intended integer optimum for both passenger
objectives and both currently supported waiting modes:

```text
waiting_time
journey_time

no_waiting
end_of_platform_wait
```

Changes that preserve only the objective value but remove dominated optimal
solutions must be identified explicitly. Changes that alter horizon or
post-horizon semantics are correctness decisions, not benchmark toggles.

## Change and Experiment Policy

Classify work before implementation:

### Direct Fix

Implement directly when the current code contradicts an already selected
model contract, applies an invalid bound, disagrees with validation, or has a
small implementation defect. Add focused tests. A temporary legacy benchmark
case may be retained to measure the performance effect, but the invalid model
must not remain a supported production option.

### Exact Reformulation

Use a selectable benchmark case when a change is intended to preserve the
integer feasible set and objective but materially changes variables,
constraints, or the LP relaxation. Verify exact small instances before
performance comparison. Promote the reformulation only after correctness and
resource effects are established.

### Semantic Alternative

Use an explicit model-policy category when alternatives intentionally define
different feasible sets, such as finite-horizon activation, conservative
continuation, depot return, or cyclic operation. Performance numbers may be
reported, but they must not be interpreted as speedups for the same model.

### Solver/Search Alternative

Keep MIP starts, solver policies, and search settings separate from model
formulations so that formulation and search effects can be measured
independently.

## Composable Experiment Configuration

Future structural experiments should extend the existing typed formulation
configuration with one value per mutually exclusive category:

```text
EanFormulationConfig
  cabin_timing: one CabinTimingFormulation
  headway_precedence: one HeadwayPrecedenceFormulation

EanOptimizationConfig
  enabled exact reductions: a set of EanOptimizationName
```

The future formulation categories in this plan are:

```text
cabin_timing:
  explicit_exit_and_wait
  transition_only

headway_precedence:
  per_checkpoint_pair
  shared_physical_precedence
```

Configurations may combine one value from each category with any compatible
set of independent reductions. Configuration validation must reject invalid
combinations, for example `tight_big_m_bounds` with a formulation that has
removed the corresponding Big-M rows.

Keep the existing single list-style CLI and structured benchmark metadata.
Every new category value receives a unique selection name, omitted categories
use their defaults, and incompatible cross-category combinations are rejected.

## Fleet Activation and Full-Day Boundaries

Optimized cabin activation, depot dispatch, fleet-size experiments, physical
depot resources, and full-day terminal contracts are specified in
`ean_fleet_activation_and_depots.md`. They change the feasible set and belong
to a separate semantic roadmap rather than the solver-preserving structural
reformulations in this document.

## Intermediate Turnbacks

Station crossovers, fixed short-turn circulation patterns, dynamic route
choices, and a future switch-graph EAN are specified in
`ean_intermediate_turnbacks.md`. They change cabin topology and passenger
reachability and are therefore not structural reductions of the current fixed
ring formulation.

## Optional Exact-Activation Time-Domain Refinement

This work is not required for the current model default. The legacy horizon
with `time_bounds_legacy_plus_10` remains the selected operational formulation.
Keep the following work deferred unless exact event-time horizon activation is
needed for its finite-horizon semantics.

The current `time_bounds_derived_visit_bounds` fallback permits up to one full
operational horizon of waiting at every waiting-enabled visit. Propagating that
allowance through every generated visit can create a very large terminal time
domain. This weakens the legacy and conservative horizon formulations, although
propagated visit bounds are necessary to make
`horizon_exact_time_activation` computationally usable.

Investigate an exact-activation-specific domain that distinguishes:

```text
active prefix:
  visits whose optimized switch entry is at or before H

boundary clearance:
  completion and resource release of the last active visit after H

inactive suffix:
  generated visits that receive no route decision after H
```

The formulation should:

- bound active switch-entry times by the operational horizon \(H\);
- preserve the complete route, occupancy, and crossing headways of every visit
  entering by \(H\);
- provide only the post-\(H\) clearance range required by the last active
  visit instead of accumulating a full-horizon wait allowance at every later
  generated visit;
- avoid detailed timing domains for an inactive suffix when those variables
  can be projected out or represented by a compact boundary state;
- retain enough finite domain for an `EARLIEST` cabin start to have an empty
  active prefix;
- use an explicit `StationEanConfig.max_wait_seconds` only when it represents
  a justified operational rule, not as an artificial solver bound;
- remain valid for both no-waiting and end-of-platform waiting.

Possible implementation approaches are:

1. Derive conditional upper bounds for active visits and separate bounds for
   the first inactive visit.
2. Remove timing and route variables for the provably inactive suffix and keep
   only the boundary-clearance expressions needed by headways.
3. Introduce a compact terminal-state representation instead of propagating
   every generated post-\(H\) visit.

Do not silently replace `time_bounds_derived_visit_bounds`. Add a separate
formulation case while evaluating the alternatives so the current six-case
matrix remains reproducible. Verification must compare exact small-instance
objectives, extracted prefixes, crossing headways, and empty-prefix cabin
starts before performance benchmarking.

## Transition-Only Cabin Timing

Using the existing affine formulation as the algebraic basis, investigate
eliminating both `exit_switch_time` and `wait_time`.

For consecutive visit entry times, define the affine minimum transition:

```text
minimum_transition
  = rope_seconds
  + skip_seconds
  + (service_seconds - skip_seconds) * stop
```

Then:

```text
minimum_transition
  <= next_switch_time - switch_time
  <= minimum_transition + wait_upper_bound * stop
```

For no-waiting visits, this collapses to one equality. Waiting is recovered as
the transition slack. Exit-switch and platform-departure times can be expressed
linearly from the current and next switch times.

The final safety visit of each cabin should preferably act as the boundary
switch time for the previous operational visit. It should not receive its own
route decision when the selected exact horizon formulation classifies it as
post-horizon boundary context.

This removes only roughly two continuous variables per operational visit while
touching extraction, MIP starts, headway expressions, and checkpoint files.
The expected size reduction is therefore small relative to the headway
disjunction count. Defer implementation until Phase 0 shows that explicit
timing variables or their coupling materially dominate model construction,
relaxation, or memory.

## Headway Structure

### Horizon Pruning

Use conservative earliest occurrence times to omit headway candidates and
pairs that are guaranteed to lie after the selected movement horizon. Recompute
the eligible set for every horizon formulation. Do not implement the reduction
until the selected horizon semantics define which post-horizon events must
remain for boundary clearance and collision safety.

### Shared Physical Precedence

The same pair of physical cabin visits currently receives separate order
binaries at platform entry, platform exit, and exit switch. Investigate sharing
one precedence binary across those checkpoints when the physical route proves
that both serving cabins cannot overtake.

Evaluate this only after the safe same-cabin and conservative reordering work in
`ean_formulation_and_search.md` has produced a reusable physical-order proof.
The proof must cover the actual route topology, skip overtaking, activation,
and end-of-platform waiting semantics.

This work refines, but does not replace, the broader conservative headway
classification work in `ean_formulation_and_search.md`.

## Lower-Priority Experiments

Solver backends that change the modeling paradigm are tracked separately in
`ean_decomposition.md`. In particular, the planned movement-only CP prototype
is an alternative scaling path, not another formulation toggle of the
integrated Gurobi MILP.

### Eliminate Unserved Variables

Substitute:

```text
unserved[group] = demand[group] - sum(selected slots)
```

into the objective and retain only:

```text
sum(selected slots) <= demand[group]
```

This is exact but removes only one integer variable per demand group. Gurobi
presolve may already perform the same substitution.

### Passenger Count Encoding

Compare the current unary threshold encoding with an exact binary expansion of
the passenger count per ride candidate. Binary expansion can reduce variables
from `Q` to approximately `ceil(log2(Q + 1))`, but weighted capacity and demand
rows are likely to give a weaker relaxation. Treat it as an isolated research
benchmark, not a default optimization.

### Slot-Time Ordering Cuts

For unary slots using a common candidate time, investigate:

```text
slot_time[k] <= slot_time[k - 1]
```

and the analogous alighting inequality. These are valid at integer solutions
and may strengthen fractional slot assignments, but they add rows and should be
tested only after redundant rows have been removed.

### Compact Headway Materialization

Separate solver performance from Python and artifact overhead:

- avoid repeated long pair identifiers in internal structures;
- consider generating pair rows from compact indexed data;
- avoid serializing identical full EAN artifacts for every benchmark run when
  the artifact is unchanged.

This targets build time, memory, and checkpoint size rather than the
branch-and-bound tree.

## Explicit Non-Priority

Do not prioritize capacity-row subset elimination unless a future scaling
diagnosis finds materially more dominated rows. The currently observed
reduction is too small to justify the implementation complexity.

## Conditional Evaluation Order

1. Keep the selected legacy horizon and time bounds unless exact finite-horizon
   activation becomes an explicit semantic requirement.
2. Run the Phase-0 bottleneck diagnosis before selecting a structural phase.
3. If explicit timing variables dominate, evaluate transition-only timing.
4. If exact horizon activation is required, refine its time domain before
   attempting post-horizon pruning.
5. If headway binaries dominate, first implement the safe classifications in
   `ean_formulation_and_search.md`, then evaluate shared physical precedence.
6. Add guaranteed post-horizon pruning only after the horizon boundary contract
   is fixed and verified.
7. Consider lower-priority experiments independently and only for a measured
   bottleneck.

Do not combine unvalidated phases in an initial benchmark. Each phase needs a
separate formulation selection or optimization toggle until objective
equivalence and performance are established.

## Verification Protocol

For each phase:

- add unit tests for the algebraic reduction or implication;
- compare feasible solutions and objectives on exact tiny instances;
- test waiting-time and journey-time objectives;
- test no-waiting and end-of-platform waiting;
- validate extracted movement and passenger plans;
- record model construction time, presolve time, variables, rows, and nonzeros;
- record root bound, first incumbent, best incumbent, best bound, gap, nodes,
  and runtime;
- run repeated five-minute `three_station_v0` benchmarks against the selected
  baseline;
- run `five_station_v0` model construction and bounded benchmarks after the
  Three-Station checks pass.

Promote an exact reformulation only when objective equivalence is established.
Promote it into the default when it also improves either proof progress,
incumbent quality, or resource use without a material regression in the other
metrics.
