# Reservoir hybrid comparison

CP progress incumbents are native solver values; final plans are independently validated. Hybrid improvements are validated at each event. Initial seed adoption is excluded.

| Case | Complete | UB | LB | Gap | Wall seconds | Peak GiB | Improvements |
|---|---|---:|---:|---:|---:|---:|---:|
| cp_sat_0 | True | 368765.820880 | 209409.890300 | 43.213% | 597.66 | 6.099 | 12 |
| hybrid_0 | True | 368765.819352 | 209409.890300 | 43.213% | 596.05 | 2.997 | 10 |
| cp_sat_1 | True | 368765.820824 | 209409.890300 | 43.213% | 597.86 | 6.569 | 19 |
| hybrid_1 | True | 368765.819528 | 209409.890300 | 43.213% | 596.03 | 3.276 | 17 |

Curve times use solver/coordinator clocks; total wall time includes process startup. Aborted runs are not equal-duration performance comparisons.

Confirmed performance recommendation: **False**.
