from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
import math

from ropeway_skip_stop_optimization.optimization.ddd.time_ticks import (
    DddTimeTick,
    ddd_headway_seconds_to_tick,
    ddd_quantize_headway_seconds,
    ddd_quantize_time_seconds,
    ddd_seconds_to_tick,
)


class DddRouteDecision(StrEnum):
    STOP = "stop"
    SKIP = "skip"


@dataclass(frozen=True)
class DddMovementState:
    id: str

    def validate(self) -> None:
        _require_id("DDD movement state id", self.id)


@dataclass(frozen=True)
class DddFixedStart:
    cabin_id: int
    state_id: str
    time_seconds: float
    max_visit_count: int

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "time_seconds",
            ddd_quantize_time_seconds(self.time_seconds),
        )

    @property
    def time_tick(self) -> DddTimeTick:
        return ddd_seconds_to_tick(self.time_seconds)

    def validate(self) -> None:
        _require_nonnegative_int("DDD fixed start cabin_id", self.cabin_id)
        _require_id("DDD fixed start state_id", self.state_id)
        _require_finite_nonnegative("DDD fixed start time_seconds", self.time_seconds)
        if self.max_visit_count <= 0:
            raise ValueError("DDD fixed start max_visit_count must be positive")


@dataclass(frozen=True)
class DddResource:
    id: str
    headway_seconds: float
    maximum_headway_seconds: float | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "headway_seconds",
            ddd_quantize_headway_seconds(self.headway_seconds),
        )
        maximum = self.maximum_headway_seconds
        if maximum is None:
            maximum = self.headway_seconds
        object.__setattr__(
            self,
            "maximum_headway_seconds",
            ddd_quantize_headway_seconds(maximum),
        )

    @property
    def headway_tick(self) -> DddTimeTick:
        """Compatibility alias for the anonymous minimum headway."""
        return self.minimum_headway_tick

    @property
    def minimum_headway_seconds(self) -> float:
        return self.headway_seconds

    @property
    def minimum_headway_tick(self) -> DddTimeTick:
        return ddd_headway_seconds_to_tick(self.headway_seconds)

    @property
    def maximum_headway_tick(self) -> DddTimeTick:
        assert self.maximum_headway_seconds is not None
        return ddd_headway_seconds_to_tick(self.maximum_headway_seconds)

    def validate(self) -> None:
        _require_id("DDD resource id", self.id)
        _require_finite_positive("DDD resource headway_seconds", self.headway_seconds)
        assert self.maximum_headway_seconds is not None
        _require_finite_positive(
            "DDD resource maximum_headway_seconds", self.maximum_headway_seconds
        )
        if self.maximum_headway_seconds < self.headway_seconds:
            raise ValueError("DDD resource maximum headway must cover its minimum")
        if self.minimum_headway_tick <= 0:
            raise ValueError("DDD resource headway must occupy at least one time tick")


@dataclass(frozen=True)
class DddResourceUsage:
    resource_id: str
    leader_clear_offset_seconds: float
    follower_enter_offset_seconds: float
    separation_after_seconds: float | None = None
    leader_clear_wait_coefficient: int = 0
    follower_enter_wait_coefficient: int = 0

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "leader_clear_offset_seconds",
            ddd_quantize_time_seconds(self.leader_clear_offset_seconds),
        )
        object.__setattr__(
            self,
            "follower_enter_offset_seconds",
            ddd_quantize_time_seconds(self.follower_enter_offset_seconds),
        )
        if self.separation_after_seconds is not None:
            object.__setattr__(
                self,
                "separation_after_seconds",
                ddd_quantize_headway_seconds(self.separation_after_seconds),
            )

    @property
    def leader_clear_offset_tick(self) -> DddTimeTick:
        return ddd_seconds_to_tick(self.leader_clear_offset_seconds)

    @property
    def follower_enter_offset_tick(self) -> DddTimeTick:
        return ddd_seconds_to_tick(self.follower_enter_offset_seconds)

    def separation_after_tick(
        self, fallback_headway_tick: DddTimeTick
    ) -> DddTimeTick:
        if self.separation_after_seconds is None:
            return fallback_headway_tick
        return ddd_headway_seconds_to_tick(self.separation_after_seconds)

    def leader_clear_offset_with_wait(self, wait_seconds: float) -> float:
        return self.leader_clear_offset_seconds + (
            self.leader_clear_wait_coefficient * wait_seconds
        )

    def follower_enter_offset_with_wait(self, wait_seconds: float) -> float:
        return self.follower_enter_offset_seconds + (
            self.follower_enter_wait_coefficient * wait_seconds
        )

    def validate(self) -> None:
        _require_id("DDD resource usage resource_id", self.resource_id)
        _require_finite_nonnegative(
            "DDD resource usage leader_clear_offset_seconds",
            self.leader_clear_offset_seconds,
        )
        _require_finite_nonnegative(
            "DDD resource usage follower_enter_offset_seconds",
            self.follower_enter_offset_seconds,
        )
        if self.separation_after_seconds is not None:
            _require_finite_positive(
                "DDD resource usage separation_after_seconds",
                self.separation_after_seconds,
            )
        if self.leader_clear_wait_coefficient not in (0, 1):
            raise ValueError("DDD leader-clear wait coefficient must be zero or one")
        if self.follower_enter_wait_coefficient not in (0, 1):
            raise ValueError("DDD follower-enter wait coefficient must be zero or one")


@dataclass(frozen=True)
class DddRouteOption:
    id: str
    from_state_id: str
    to_state_id: str
    station_id: str
    decision: DddRouteDecision
    duration_seconds: float
    platform_entry_offset_seconds: float | None
    platform_exit_offset_seconds: float | None
    exit_switch_offset_seconds: float
    resource_usages: tuple[DddResourceUsage, ...]

    def __post_init__(self) -> None:
        for name in (
            "duration_seconds",
            "platform_entry_offset_seconds",
            "platform_exit_offset_seconds",
            "exit_switch_offset_seconds",
        ):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(
                    self,
                    name,
                    ddd_quantize_time_seconds(value),
                )

    @property
    def duration_tick(self) -> DddTimeTick:
        return ddd_seconds_to_tick(self.duration_seconds)

    @property
    def exit_switch_offset_tick(self) -> DddTimeTick:
        return ddd_seconds_to_tick(self.exit_switch_offset_seconds)

    def validate(self) -> None:
        for label, value in (
            ("DDD route option id", self.id),
            ("DDD route option from_state_id", self.from_state_id),
            ("DDD route option to_state_id", self.to_state_id),
            ("DDD route option station_id", self.station_id),
        ):
            _require_id(label, value)
        if not isinstance(self.decision, DddRouteDecision):
            raise ValueError("DDD route option needs a valid decision")
        _require_finite_positive("DDD route option duration_seconds", self.duration_seconds)
        _require_finite_nonnegative(
            "DDD route option exit_switch_offset_seconds",
            self.exit_switch_offset_seconds,
        )
        if self.duration_tick <= 0:
            raise ValueError("DDD route duration must occupy at least one time tick")
        if self.exit_switch_offset_tick > self.duration_tick:
            raise ValueError("DDD route option exit switch must not follow its arrival")
        if self.decision is DddRouteDecision.STOP:
            if (
                self.platform_entry_offset_seconds is None
                or self.platform_exit_offset_seconds is None
            ):
                raise ValueError("DDD STOP route needs platform offsets")
            _require_finite_nonnegative(
                "DDD route option platform_entry_offset_seconds",
                self.platform_entry_offset_seconds,
            )
            _require_finite_nonnegative(
                "DDD route option platform_exit_offset_seconds",
                self.platform_exit_offset_seconds,
            )
            if not (
                self.platform_entry_offset_seconds
                <= self.platform_exit_offset_seconds
                <= self.exit_switch_offset_seconds
            ):
                raise ValueError("DDD STOP route offsets must be monotone")
        elif (
            self.platform_entry_offset_seconds is not None
            or self.platform_exit_offset_seconds is not None
        ):
            raise ValueError("DDD SKIP route must not define platform offsets")
        for usage in self.resource_usages:
            usage.validate()
            if max(
                usage.leader_clear_offset_seconds,
                usage.follower_enter_offset_seconds,
            ) > self.duration_seconds:
                raise ValueError("DDD resource usage must lie within its route")


@dataclass(frozen=True)
class DddMovementCore:
    """Start-independent physical movement domain shared by DDD formulations."""

    scenario_id: str
    passenger_service_end_seconds: float
    operational_end_seconds: float
    states: tuple[DddMovementState, ...]
    route_options: tuple[DddRouteOption, ...]
    resources: tuple[DddResource, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "passenger_service_end_seconds",
            ddd_quantize_time_seconds(self.passenger_service_end_seconds),
        )
        object.__setattr__(
            self,
            "operational_end_seconds",
            ddd_quantize_time_seconds(self.operational_end_seconds),
        )

    @property
    def passenger_service_end_tick(self) -> DddTimeTick:
        return ddd_seconds_to_tick(self.passenger_service_end_seconds)

    @property
    def operational_end_tick(self) -> DddTimeTick:
        return ddd_seconds_to_tick(self.operational_end_seconds)

    def validate(self) -> None:
        _require_id("DDD movement problem scenario_id", self.scenario_id)
        _require_finite_positive(
            "DDD passenger_service_end_seconds",
            self.passenger_service_end_seconds,
        )
        _require_finite_positive(
            "DDD operational_end_seconds",
            self.operational_end_seconds,
        )
        if self.passenger_service_end_tick <= 0 or self.operational_end_tick <= 0:
            raise ValueError("DDD horizons must occupy at least one time tick")
        if self.operational_end_tick < self.passenger_service_end_tick:
            raise ValueError("DDD operational horizon must include passenger service")
        if not self.states or not self.route_options:
            raise ValueError("DDD movement core needs states and route options")

        state_ids = _validate_unique_ids("DDD movement state", self.states)
        resource_ids = _validate_unique_ids("DDD resource", self.resources)
        option_ids = _validate_unique_ids("DDD route option", self.route_options)
        if not option_ids:
            raise ValueError("DDD movement problem needs route options")
        for state in self.states:
            state.validate()
        for resource in self.resources:
            resource.validate()
        outgoing_state_ids: set[str] = set()
        for option in self.route_options:
            option.validate()
            if option.from_state_id not in state_ids or option.to_state_id not in state_ids:
                raise ValueError("DDD route option references an unknown state")
            unknown_resources = {
                usage.resource_id for usage in option.resource_usages
            } - resource_ids
            if unknown_resources:
                raise ValueError(
                    f"DDD route option references unknown resources: {unknown_resources}"
                )
            resources_by_id = self.resources_by_id
            for usage in option.resource_usages:
                resource = resources_by_id[usage.resource_id]
                exact_tick = usage.separation_after_tick(resource.minimum_headway_tick)
                if not (
                    resource.minimum_headway_tick
                    <= exact_tick
                    <= resource.maximum_headway_tick
                ):
                    raise ValueError(
                        "DDD resource usage separation lies outside the resource "
                        f"envelope: option={option.id!r}, resource={resource.id!r}"
                    )
            outgoing_state_ids.add(option.from_state_id)

    @property
    def route_options_by_state_id(self) -> dict[str, tuple[DddRouteOption, ...]]:
        grouped: dict[str, list[DddRouteOption]] = {}
        for option in self.route_options:
            grouped.setdefault(option.from_state_id, []).append(option)
        return {
            state_id: tuple(sorted(options, key=lambda option: option.id))
            for state_id, options in grouped.items()
        }

    @property
    def resources_by_id(self) -> dict[str, DddResource]:
        return {resource.id: resource for resource in self.resources}


@dataclass(frozen=True)
class DddMovementProblem:
    """Compatibility wrapper for the original fixed-start DDD interface."""

    scenario_id: str
    passenger_service_end_seconds: float
    operational_end_seconds: float
    states: tuple[DddMovementState, ...]
    starts: tuple[DddFixedStart, ...]
    route_options: tuple[DddRouteOption, ...]
    resources: tuple[DddResource, ...]

    def __post_init__(self) -> None:
        core = self.core
        object.__setattr__(
            self, "passenger_service_end_seconds", core.passenger_service_end_seconds
        )
        object.__setattr__(
            self, "operational_end_seconds", core.operational_end_seconds
        )

    @property
    def core(self) -> DddMovementCore:
        return DddMovementCore(
            scenario_id=self.scenario_id,
            passenger_service_end_seconds=self.passenger_service_end_seconds,
            operational_end_seconds=self.operational_end_seconds,
            states=self.states,
            route_options=self.route_options,
            resources=self.resources,
        )

    @property
    def passenger_service_end_tick(self) -> DddTimeTick:
        return self.core.passenger_service_end_tick

    @property
    def operational_end_tick(self) -> DddTimeTick:
        return self.core.operational_end_tick

    def validate(self) -> None:
        self.core.validate()
        if not self.starts:
            raise ValueError("DDD movement problem needs fixed starts")
        state_ids = {state.id for state in self.states}
        outgoing_state_ids = {option.from_state_id for option in self.route_options}
        cabin_ids: set[int] = set()
        for start in self.starts:
            start.validate()
            if start.cabin_id in cabin_ids:
                raise ValueError(f"duplicate DDD cabin start id: {start.cabin_id}")
            cabin_ids.add(start.cabin_id)
            if start.state_id not in state_ids:
                raise ValueError("DDD fixed start references an unknown state")
            if start.time_tick > self.operational_end_tick:
                raise ValueError("DDD fixed start lies after the operational horizon")
        if {start.state_id for start in self.starts} - outgoing_state_ids:
            raise ValueError("DDD fixed start state has no outgoing route option")

    @property
    def route_options_by_state_id(self) -> dict[str, tuple[DddRouteOption, ...]]:
        return self.core.route_options_by_state_id

    @property
    def resources_by_id(self) -> dict[str, DddResource]:
        return self.core.resources_by_id


def _validate_unique_ids(label: str, values: tuple[object, ...]) -> set[str]:
    ids = [getattr(value, "id") for value in values]
    if len(ids) != len(set(ids)):
        raise ValueError(f"duplicate {label} ids")
    return set(ids)


def _require_id(label: str, value: str) -> None:
    if not value.strip():
        raise ValueError(f"{label} must be nonempty")


def _require_nonnegative_int(label: str, value: int) -> None:
    if value < 0:
        raise ValueError(f"{label} must be nonnegative")


def _require_finite_nonnegative(label: str, value: float) -> None:
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"{label} must be finite and nonnegative")


def _require_finite_positive(label: str, value: float) -> None:
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{label} must be finite and positive")
