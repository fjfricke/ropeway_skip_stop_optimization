# Freie Passagiere und Konfliktnachbarschaften: Vergleich

Gemeinsamer Startwert: 368765.817136. Globale externe LB: 209409.890300.
Lokale Bounds sind keine globalen Bounds. Seedübernahme zählt nicht als Verbesserung.

| Lauf | Status | Kosten | Gewinn | Variablen | Zeit s | Peak GiB |
|---|---|---:|---:|---:|---:|---:|
| screen_legacy_original_0 | FEASIBLE | 368765.817136 | 0.000000 | 6211 | 27.92 | 1.61 |
| screen_global_original_0 | FEASIBLE | 368765.817136 | 0.000000 | 15725 | 28.00 | 1.86 |
| screen_legacy_original_1 | FEASIBLE | 368765.817136 | 0.000000 | 5565 | 27.89 | 1.54 |
| screen_global_original_1 | FEASIBLE | 368765.817136 | 0.000000 | 15658 | 28.03 | 2.10 |
| screen_legacy_original_2 | FEASIBLE | 368765.817136 | 0.000000 | 12491 | 28.17 | 2.05 |
| screen_global_original_2 | FEASIBLE | 368765.817136 | 0.000000 | 22283 | 28.22 | 2.86 |
| screen_legacy_original_3 | FEASIBLE | 368765.817136 | 0.000000 | 11125 | 28.27 | 2.54 |
| screen_global_original_3 | FEASIBLE | 368765.817136 | 0.000000 | 22065 | 28.20 | 2.80 |
| screen_global_conflict_0 | FEASIBLE | 368765.817136 | 0.000000 | 15707 | 28.18 | 2.14 |
| screen_global_conflict_1 | FEASIBLE | 368765.817136 | 0.000000 | 15706 | 27.90 | 1.80 |
| screen_global_conflict_2 | FEASIBLE | 368765.817136 | 0.000000 | 15695 | 28.05 | 1.83 |
| screen_global_conflict_3 | FEASIBLE | 368765.817136 | 0.000000 | 15702 | 27.96 | 2.15 |
| confirm_global_1 | FEASIBLE | 368765.817136 | 0.000000 | 15707 | 118.19 | 2.28 |
| confirm_legacy_1 | FEASIBLE | 368765.817136 | 0.000000 | 6251 | 117.97 | 2.49 |
| confirm_full_1 | FEASIBLE | 368765.817136 | 0.000000 | 87020 | 119.69 | 5.80 |
| confirm_global_2 | FEASIBLE | 368765.817136 | 0.000000 | 15707 | 118.14 | 2.87 |
| confirm_legacy_2 | FEASIBLE | 368765.817136 | 0.000000 | 6251 | 118.07 | 2.37 |
| confirm_full_2 | FEASIBLE | 368765.817136 | 0.000000 | 87020 | 119.50 | 6.01 |

Bestätigter Performancevorteil: **False**.
Gesamte Wandzeit: 1048.85 Sekunden; Budget 1800 Sekunden.
Schwelle: mindestens 0.1% bessere Kosten als beide Kontrollen, in beiden zusätzlichen Seeds.
CP-Zwischenwerte sind native Solverwerte; Endpläne sind unabhängig validiert. Lokale Verbesserungen werden vor Akzeptanz unabhängig geprüft.
